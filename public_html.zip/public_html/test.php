<?php

// $name=$_GET["n"];
// $dob=$_GET["d"];
$phone=$_GET["p"];

echo $phone;



?>


